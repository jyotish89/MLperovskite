# Perovskite Band-Gap Uncertainty Quantification: Results Summary

## Data

The master dataset (24,798 rows) was cleaned by removing 494 literal exact-duplicate rows and 14,244 rows lacking every site-identity and geometric descriptor (formula and calc_method were always present and never used to justify exclusion). No implausible internal inconsistency was found between the derived descriptors (tolerance factor, octahedral factor, radius ratios) and r_A/r_B/r_X (max recomputation error ~1e-15), so no additional records were excluded on that basis; out-of-typical-range values were flagged (5,762 rows) but retained. This leaves 10,060 rows: 9,235 low-fidelity (calc_method outside the HSE06 family) and 825 high-fidelity (DFT-HSE06 (relaxed), DFT-HSE06+SOC (relaxed), DFT-HSE06+SOC (on PBE geometry)), with 297 formulas appearing in both pools.

## Model tuning

A base HistGradientBoostingRegressor (MAE objective) and two pinball-loss quantile regressors (alpha=0.025, 0.975) were tuned once on the complete low-fidelity pool with formula-grouped 5-fold cross-validation and a 40-iteration randomized search each; the selected configurations were reused, unmodified, throughout all downstream evaluation (see `tuned_config.json` and the model table for exact hyperparameters).

## Main benchmark (20 formula-disjoint calibration/test splits)

All four UQ methods were evaluated on 20 independently seeded, formula-disjoint calibration/test partitions of the high-fidelity pool (50% calibration / 50% test). Global split conformal achieved approximately 96.3% coverage (95% bootstrap CI [95.6%, 96.9%]) against a 95% nominal target -- close to nominal coverage, not unqualified 'reliable' coverage. Mondrian (B-site-conditional) conformal, direct quantile-GB intervals, and GPR intervals are compared in the benchmark table; quantile-GB intervals in particular substantially undercover relative to nominal, illustrating that uncalibrated pinball-loss bounds should not be read as valid prediction intervals on their own.

## Extrapolation (LOBO)

Leave-one-site-out analyses (5 fixed seeds each, recalibrated global-conformal quantile per fold) show coverage degrading most for X-site extrapolation (90.5%) relative to A-site (97.4%) and B-site (96.9%) extrapolation, consistent with X-site chemistry driving band-gap behavior in ways the calibration set does not fully anticipate when a wholly new X-site species is encountered.

## Novelty analysis

Ranking high-fidelity test rows into novelty quartiles by distance to the low-fidelity reference distribution gives materially different rankings depending on distance metric: Euclidean and Mahalanobis quartile assignments agree for only 23.2% of rows (Spearman rank correlation 0.07 between the two raw distances). This is a genuine sensitivity finding: conclusions about which compositions are 'novel' should not be treated as robust to the choice of distance metric without further scrutiny.

## Sensitivity analyses

Mondrian minimum-group thresholds of 5/10/15/20 were compared (see `sensitivity_mondrian_threshold.csv`); the GPR training-set ladder (500/1,000/2,000/4,000 low-fidelity rows) was evaluated on the full high-fidelity pool (see `sensitivity_gpr_ladder.csv`). No full-data GP was attempted. 0 ladder point(s) were marked infeasible where requested.

## Validity caveat

**Validity caveat.** Split-conformal validity relies on exchangeability between calibration and test data. This assumption is violated for compositions containing a B-site, A-site, or X-site category unseen during calibration; in that regime the reported coverage guarantees do not extend, and the intervals carry no built-in warning flag for this failure mode. Users extrapolating to novel site chemistries should treat interval widths as indicative rather than guaranteed, and consult the LOBO and novelty-quartile results in this report before trusting an interval for an unfamiliar composition.
