### Four-method UQ benchmark aggregated over 20 formula-disjoint calibration/test splits (bootstrap CIs).

| method             |   n_seeds |   coverage_mean |   coverage_boot_lo |   coverage_boot_hi |   width_mean |   width_boot_lo |   width_boot_hi |
|:-------------------|----------:|----------------:|-------------------:|-------------------:|-------------:|----------------:|----------------:|
| global_conformal   |        20 |          0.9629 |             0.9562 |             0.9689 |       3.7769 |          3.7283 |          3.8186 |
| gpr                |        20 |          0.8904 |             0.8826 |             0.8982 |       3.4726 |          3.4644 |          3.4801 |
| mondrian_conformal |        20 |          0.9579 |             0.9496 |             0.966  |       3.8928 |          3.8023 |          3.9842 |
| quantile_gb        |        20 |          0.5037 |             0.492  |             0.5151 |       3.7591 |          3.7406 |          3.7792 |
