### Leave-one-site-out extrapolation coverage/width by site type (5 fixed seeds, bootstrap CIs).

| site_type   |   n_held_out_values |   n_records |   coverage_mean |   coverage_boot_lo |   coverage_boot_hi |   width_mean |   width_boot_lo |   width_boot_hi |
|:------------|--------------------:|------------:|----------------:|-------------------:|-------------------:|-------------:|----------------:|----------------:|
| A_site      |                  17 |          85 |          0.9736 |             0.9635 |             0.9827 |       3.7289 |          3.6972 |          3.7587 |
| B_site      |                  54 |         270 |          0.9694 |             0.9567 |             0.981  |       3.7331 |          3.7153 |          3.7506 |
| X_site      |                  10 |          50 |          0.9055 |             0.8661 |             0.9403 |       3.7135 |          3.6741 |          3.7513 |
