### Dataset validation and fidelity-pool summary.

| quantity                                        |   value |
|:------------------------------------------------|--------:|
| Input rows                                      |   24798 |
| Exact duplicate rows removed                    |     494 |
| Fully-missing rows removed                      |   14244 |
| Rows retained after cleaning                    |   10060 |
| Low-fidelity rows                               |    9235 |
| High-fidelity (HSE06-family) rows               |     825 |
| Unique low-fidelity formulas                    |    7168 |
| Unique high-fidelity formulas                   |     299 |
| Formulas overlapping between pools              |     297 |
| Rows flagged out of physical range (audit only) |    5762 |
