#!/usr/bin/env python3
"""Phase 1 CLI: validation and audit. Checkpointed to data/checkpoints/."""
import sys
from pathlib import Path
sys.path.insert(0, str(Path(__file__).resolve().parents[1] / "src"))
import data_validation as dv

if __name__ == "__main__":
    df_clean, report = dv.run(save=True)
    print(f"Cleaned rows: {len(df_clean)} (see results/tables/cleaning_report.md)")
