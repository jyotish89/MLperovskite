#!/usr/bin/env python3
"""Phase 3 CLI: 20-seed UQ benchmark. Requires run_validation.py and
run_tuning.py to have been run first."""
import sys
from pathlib import Path
sys.path.insert(0, str(Path(__file__).resolve().parents[1] / "src"))
import config as cfg
import data_validation as dv
import fidelity as fid
import repeated_evaluation as reval
import pandas as pd

if __name__ == "__main__":
    ckpt = cfg.CACHE_DIR / "clean_data.parquet"
    df_clean = pd.read_parquet(ckpt) if ckpt.exists() else dv.run(save=True)[0]
    lf, hf = fid.split(df_clean)
    row_level, per_seed_df, agg_df = reval.run(lf, hf, save=True)
    print(agg_df.to_string())
