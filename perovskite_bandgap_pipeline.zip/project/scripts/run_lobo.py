#!/usr/bin/env python3
"""Phase 4 CLI: LOBO extrapolation + novelty quartiles. Requires the main
benchmark (run_repeated_benchmark.py) to have been run first."""
import sys
from pathlib import Path
sys.path.insert(0, str(Path(__file__).resolve().parents[1] / "src"))
import config as cfg
import data_validation as dv
import fidelity as fid
import extrapolation as extra
import pandas as pd

if __name__ == "__main__":
    ckpt = cfg.CACHE_DIR / "clean_data.parquet"
    df_clean = pd.read_parquet(ckpt) if ckpt.exists() else dv.run(save=True)[0]
    lf, hf = fid.split(df_clean)
    main_row_level = pd.read_csv(cfg.CACHE_DIR / "main_benchmark_row_level.csv")
    lobo_detail, lobo_agg, euclid_summary, mahal_summary, sens = extra.run(lf, hf, main_row_level, save=True)
    print(lobo_agg.to_string())
    print(sens)
