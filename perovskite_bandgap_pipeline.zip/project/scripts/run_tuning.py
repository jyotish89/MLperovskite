#!/usr/bin/env python3
"""Phase 2 CLI: model tuning on the low-fidelity pool. Requires run_validation.py
to have been run first (reads data/checkpoints/clean_data.parquet)."""
import sys
import json
from pathlib import Path
sys.path.insert(0, str(Path(__file__).resolve().parents[1] / "src"))
import config as cfg
import data_validation as dv
import fidelity as fid
import tuning as tn
import pandas as pd

if __name__ == "__main__":
    ckpt = cfg.CACHE_DIR / "clean_data.parquet"
    if ckpt.exists():
        df_clean = pd.read_parquet(ckpt)
    else:
        df_clean, _ = dv.run(save=True)
    lf, hf = fid.split(df_clean)
    results = tn.run(lf, save=True)
    print(json.dumps(results, indent=2, default=str))
