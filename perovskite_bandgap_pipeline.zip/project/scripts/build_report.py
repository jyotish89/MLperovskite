#!/usr/bin/env python3
"""Phase 6 CLI: figures, tables, and Markdown/LaTeX manuscript outputs.
Requires all prior phases (validation, tuning, benchmark, LOBO, sensitivity)
to have been run first -- this script only reads their checkpointed outputs."""
import sys
from pathlib import Path
sys.path.insert(0, str(Path(__file__).resolve().parents[1] / "src"))
import tables
import plots
import report_generation as report

if __name__ == "__main__":
    tables.run()
    plots.run_all()
    report.run()
    print("Done. See results/figures, results/tables, results/markdown, results/latex.")
