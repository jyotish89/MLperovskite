#!/usr/bin/env python3
"""Phase 5 CLI: Mondrian threshold sensitivity + GPR row-count ladder.
Requires run_tuning.py to have been run first."""
import sys
from pathlib import Path
sys.path.insert(0, str(Path(__file__).resolve().parents[1] / "src"))
import config as cfg
import data_validation as dv
import fidelity as fid
import sensitivity as sens
import pandas as pd

if __name__ == "__main__":
    ckpt = cfg.CACHE_DIR / "clean_data.parquet"
    df_clean = pd.read_parquet(ckpt) if ckpt.exists() else dv.run(save=True)[0]
    lf, hf = fid.split(df_clean)
    mond_df, gpr_df = sens.run(lf, hf, save=True)
    print(mond_df.to_string())
    print(gpr_df.to_string())
