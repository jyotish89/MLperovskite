"""
Phase 2 (part 2): tune once on the complete low-fidelity pool using
formula-grouped 5-fold CV.
  - base HistGradientBoostingRegressor: randomized MAE search, 40 iterations
  - lower/upper quantile HGB regressors: separate pinball-loss randomized
    searches with the same grouped-CV discipline
Selected configurations are reused throughout repeated evaluation (never
retuned per split).
"""
from __future__ import annotations
import sys
import json
import functools
import platform
import sklearn
import numpy as np
import pandas as pd
from sklearn.ensemble import HistGradientBoostingRegressor
from sklearn.model_selection import RandomizedSearchCV, GroupKFold
from sklearn.metrics import make_scorer, mean_absolute_error, mean_pinball_loss

sys.path.insert(0, str(__import__("pathlib").Path(__file__).resolve().parent))
import config as cfg
import preprocessing as pp


def _mae_scorer():
    return make_scorer(mean_absolute_error, greater_is_better=False)


def _pinball_scorer(alpha: float):
    return make_scorer(
        functools.partial(mean_pinball_loss, alpha=alpha), greater_is_better=False
    )


def tune_base(lf_df: pd.DataFrame, n_iter=cfg.RANDOM_SEARCH_N_ITER, seed=cfg.TUNING_SEED):
    X, y = pp.X_y(pp.to_model_frame(lf_df))
    groups = lf_df[cfg.GROUP_KEY].to_numpy()
    cv = GroupKFold(n_splits=cfg.CV_N_SPLITS)
    base = HistGradientBoostingRegressor(
        loss="squared_error", categorical_features="from_dtype", random_state=seed
    )
    search = RandomizedSearchCV(
        base, cfg.HGB_BASE_PARAM_DIST, n_iter=n_iter, scoring=_mae_scorer(),
        cv=cv, random_state=seed, n_jobs=1, refit=False,
    )
    search.fit(X, y, groups=groups)
    return search.best_params_, search.best_score_, search.cv_results_


def tune_quantile(lf_df: pd.DataFrame, alpha: float, n_iter=cfg.RANDOM_SEARCH_N_ITER, seed=cfg.TUNING_SEED):
    X, y = pp.X_y(pp.to_model_frame(lf_df))
    groups = lf_df[cfg.GROUP_KEY].to_numpy()
    cv = GroupKFold(n_splits=cfg.CV_N_SPLITS)
    model = HistGradientBoostingRegressor(
        loss="quantile", quantile=alpha, categorical_features="from_dtype", random_state=seed
    )
    search = RandomizedSearchCV(
        model, cfg.HGB_QUANTILE_PARAM_DIST, n_iter=n_iter, scoring=_pinball_scorer(alpha),
        cv=cv, random_state=seed, n_jobs=1, refit=False,
    )
    search.fit(X, y, groups=groups)
    return search.best_params_, search.best_score_, search.cv_results_


def dependency_versions():
    import numpy, scipy
    return {
        "python": platform.python_version(),
        "sklearn": sklearn.__version__,
        "numpy": numpy.__version__,
        "scipy": scipy.__version__,
        "pandas": pd.__version__,
    }


def run(lf_df: pd.DataFrame, save=True):
    results = {}
    base_params, base_score, base_cv = tune_base(lf_df)
    lo_params, lo_score, lo_cv = tune_quantile(lf_df, cfg.QUANTILE_LOWER)
    hi_params, hi_score, hi_cv = tune_quantile(lf_df, cfg.QUANTILE_UPPER)

    results["base"] = {"best_params": base_params, "best_cv_score_neg_mae": base_score}
    results["quantile_lower"] = {
        "quantile": cfg.QUANTILE_LOWER, "best_params": lo_params,
        "best_cv_score_neg_pinball": lo_score,
    }
    results["quantile_upper"] = {
        "quantile": cfg.QUANTILE_UPPER, "best_params": hi_params,
        "best_cv_score_neg_pinball": hi_score,
    }
    results["cv_scheme"] = f"GroupKFold(n_splits={cfg.CV_N_SPLITS}) grouped by formula"
    results["random_search_n_iter"] = cfg.RANDOM_SEARCH_N_ITER
    results["tuning_seed"] = cfg.TUNING_SEED
    results["dependency_versions"] = dependency_versions()
    results["n_low_fidelity_rows_used"] = len(lf_df)
    results["n_low_fidelity_unique_formulas"] = lf_df[cfg.GROUP_KEY].nunique()

    if save:
        with open(cfg.CACHE_DIR / "tuned_config.json", "w") as f:
            json.dump(results, f, indent=2, default=str)
        # also persist full cv_results_ for base model for auditability
        pd.DataFrame(base_cv).to_csv(cfg.CACHE_DIR / "cv_results_base.csv", index=False)
        pd.DataFrame(lo_cv).to_csv(cfg.CACHE_DIR / "cv_results_quantile_lower.csv", index=False)
        pd.DataFrame(hi_cv).to_csv(cfg.CACHE_DIR / "cv_results_quantile_upper.csv", index=False)
    return results


if __name__ == "__main__":
    import data_validation as dv
    import fidelity as fid

    df_clean, _ = dv.run(save=False)
    lf, hf = fid.split(df_clean)
    res = run(lf)
    print(json.dumps(res, indent=2, default=str))
