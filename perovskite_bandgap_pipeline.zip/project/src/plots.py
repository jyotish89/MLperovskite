"""Phase 6: figures -- workflow diagram, parity plot, per-site widths,
calibration curves, feature importance, LOBO plots, novelty-binned results."""
from __future__ import annotations
import sys
import numpy as np
import pandas as pd
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt

sys.path.insert(0, str(__import__("pathlib").Path(__file__).resolve().parent))
import config as cfg

plt.rcParams.update({"figure.dpi": 130, "font.size": 9, "axes.grid": True, "grid.alpha": 0.3})


def fig_workflow_diagram():
    fig, ax = plt.subplots(figsize=(9, 3.2))
    ax.axis("off")
    steps = [
        "Raw CSV\n(24,798 rows)", "Validation &\ncleaning\n(10,060 rows)",
        "Fidelity split\nLF=9,235 / HF=825", "Tune base +\nquantile models\n(grouped 5-fold CV)",
        "20-seed UQ\nbenchmark", "LOBO +\nnovelty", "Sensitivity\nanalyses", "Figures, tables\n& manuscript",
    ]
    n = len(steps)
    xs = np.linspace(0.03, 0.97, n)
    for i, (x, s) in enumerate(zip(xs, steps)):
        ax.add_patch(plt.Rectangle((x - 0.055, 0.35), 0.11, 0.3, fill=True,
                                    facecolor="#dbe9f7", edgecolor="#2b6cb0", zorder=2))
        ax.text(x, 0.5, s, ha="center", va="center", fontsize=7.3, zorder=3)
        if i < n - 1:
            ax.annotate("", xy=(xs[i + 1] - 0.06, 0.5), xytext=(x + 0.06, 0.5),
                        arrowprops=dict(arrowstyle="->", color="#4a5568"))
    ax.set_xlim(0, 1); ax.set_ylim(0, 1)
    ax.set_title("Pipeline workflow", fontsize=11)
    fig.tight_layout()
    fig.savefig(cfg.FIG_DIR / "workflow_diagram.png")
    plt.close(fig)


def fig_parity(row_level: pd.DataFrame):
    sub = row_level[row_level["method"] == "global_conformal"]
    fig, ax = plt.subplots(figsize=(4.5, 4.5))
    ax.scatter(sub["y_true"], sub["point_pred"], s=6, alpha=0.25, color="#2b6cb0")
    lims = [0, max(sub["y_true"].max(), sub["point_pred"].max()) * 1.05]
    ax.plot(lims, lims, "k--", lw=1)
    ax.set_xlim(lims); ax.set_ylim(lims)
    ax.set_xlabel("True band gap (eV)"); ax.set_ylabel("Predicted band gap (eV)")
    ax.set_title("Parity plot -- base model on high-fidelity test rows\n(pooled across 20 seeds)")
    fig.tight_layout()
    fig.savefig(cfg.FIG_DIR / "parity_plot.png")
    plt.close(fig)


def fig_per_site_widths(row_level: pd.DataFrame, top_n=15):
    sub = row_level[row_level["method"] == "global_conformal"]
    grp = sub.groupby("B_site")["width"].mean().sort_values(ascending=False).head(top_n)
    fig, ax = plt.subplots(figsize=(6, 4.5))
    ax.barh(grp.index[::-1], grp.values[::-1], color="#2b6cb0")
    ax.set_xlabel("Mean conformal interval width (eV)")
    ax.set_title(f"Top {top_n} B-site groups by mean interval width\n(global conformal, pooled over 20 seeds)")
    fig.tight_layout()
    fig.savefig(cfg.FIG_DIR / "per_site_widths.png")
    plt.close(fig)


def fig_calibration_curve(per_seed_df: pd.DataFrame):
    fig, ax = plt.subplots(figsize=(5.5, 4.5))
    methods = per_seed_df["method"].unique()
    for m in methods:
        sub = per_seed_df[per_seed_df["method"] == m].sort_values("seed")
        ax.errorbar(
            range(len(sub)), sub["coverage"],
            yerr=[sub["coverage"] - sub["coverage_wilson_lo"], sub["coverage_wilson_hi"] - sub["coverage"]],
            marker="o", ms=3, lw=1, capsize=2, label=m,
        )
    ax.axhline(1 - cfg.ALPHA, color="k", ls="--", lw=1, label=f"{int((1-cfg.ALPHA)*100)}% target")
    ax.set_xlabel("Seed index (1..20)"); ax.set_ylabel("Empirical coverage (Wilson CI)")
    ax.set_title("Per-seed coverage by UQ method")
    ax.legend(fontsize=6.5, loc="lower right")
    fig.tight_layout()
    fig.savefig(cfg.FIG_DIR / "calibration_curve.png")
    plt.close(fig)


def fig_feature_importance():
    import joblib
    import preprocessing as pp
    import models as mdl
    import data_validation as dv
    import fidelity as fid
    from sklearn.inspection import permutation_importance

    df_clean, _ = dv.run(save=False)
    lf, hf = fid.split(df_clean)
    lf_m = pp.to_model_frame(lf)
    tuned = mdl.load_tuned_config()
    base = mdl.build_base_model(tuned)
    X, y = pp.X_y(lf_m)
    base.fit(X, y)
    result = permutation_importance(base, X, y, n_repeats=5, random_state=0, n_jobs=1)
    order = np.argsort(result.importances_mean)
    fig, ax = plt.subplots(figsize=(6, 4.5))
    ax.barh(np.array(cfg.FEATURES)[order], result.importances_mean[order],
            xerr=result.importances_std[order], color="#2b6cb0")
    ax.set_xlabel("Permutation importance (MAE increase)")
    ax.set_title("Feature importance -- base model (low-fidelity pool)")
    fig.tight_layout()
    fig.savefig(cfg.FIG_DIR / "feature_importance.png")
    plt.close(fig)


def fig_lobo(lobo_agg: pd.DataFrame):
    fig, ax = plt.subplots(figsize=(5.5, 4))
    x = np.arange(len(lobo_agg))
    ax.bar(x, lobo_agg["coverage_mean"],
           yerr=[lobo_agg["coverage_mean"] - lobo_agg["coverage_boot_lo"],
                 lobo_agg["coverage_boot_hi"] - lobo_agg["coverage_mean"]],
           capsize=4, color="#2b6cb0")
    ax.axhline(1 - cfg.ALPHA, color="k", ls="--", lw=1, label=f"{int((1-cfg.ALPHA)*100)}% target")
    ax.set_xticks(x); ax.set_xticklabels(lobo_agg["site_type"])
    ax.set_ylabel("Coverage (bootstrap CI across held-out values x 5 seeds)")
    ax.set_title("LOBO extrapolation coverage by site type")
    ax.legend(fontsize=8)
    fig.tight_layout()
    fig.savefig(cfg.FIG_DIR / "lobo_coverage.png")
    plt.close(fig)


def fig_novelty(euclid_summary: pd.DataFrame, mahal_summary: pd.DataFrame):
    fig, axes = plt.subplots(1, 2, figsize=(9, 4), sharey=True)
    for ax, summary, title in zip(axes, [euclid_summary, mahal_summary],
                                   ["Euclidean distance quartiles", "Mahalanobis distance quartiles"]):
        ax.bar(summary["quartile"], summary["coverage"],
               yerr=[summary["coverage"] - summary["coverage_wilson_lo"],
                     summary["coverage_wilson_hi"] - summary["coverage"]],
               capsize=4, color="#2b6cb0")
        ax.axhline(1 - cfg.ALPHA, color="k", ls="--", lw=1)
        ax.set_xlabel("Novelty quartile (1=most familiar, 4=most novel)")
        ax.set_title(title, fontsize=9)
    axes[0].set_ylabel("Coverage (Wilson CI)")
    fig.suptitle("Global-conformal coverage by novelty quartile", fontsize=10)
    fig.tight_layout()
    fig.savefig(cfg.FIG_DIR / "novelty_binned.png")
    plt.close(fig)


def run_all():
    row_level = pd.read_csv(cfg.CACHE_DIR / "main_benchmark_row_level.csv")
    per_seed_df = pd.read_csv(cfg.CACHE_DIR / "main_benchmark_per_seed.csv")
    lobo_agg = pd.read_csv(cfg.TAB_DIR / "lobo_aggregate.csv")
    euclid_summary = pd.read_csv(cfg.TAB_DIR / "novelty_euclidean.csv")
    mahal_summary = pd.read_csv(cfg.TAB_DIR / "novelty_mahalanobis.csv")

    fig_workflow_diagram()
    fig_parity(row_level)
    fig_per_site_widths(row_level)
    fig_calibration_curve(per_seed_df)
    fig_feature_importance()
    fig_lobo(lobo_agg)
    fig_novelty(euclid_summary, mahal_summary)
    print("All figures saved to", cfg.FIG_DIR)


if __name__ == "__main__":
    run_all()
