"""
Four UQ interval-construction methods evaluated in the main benchmark:
  1. global_conformal      -- split conformal on base-model absolute residuals
  2. mondrian_conformal     -- per-B-site-group conformal (fixed Mondrian default:
                                groups with < MONDRIAN_DEFAULT_MIN_GROUP calibration
                                rows fall back to the global quantile)
  3. quantile_gb_interval   -- direct pinball-loss quantile-GB bounds
  4. gpr_interval           -- Gaussian Process predictive mean +/- z*std

Fixed conformal quantile convention throughout: ceil((n+1)(1-alpha))/n
empirical quantile (see config.conformal_quantile_level).
"""
from __future__ import annotations
import sys
import numpy as np
import pandas as pd

sys.path.insert(0, str(__import__("pathlib").Path(__file__).resolve().parent))
import config as cfg


def _empirical_quantile(residuals: np.ndarray, alpha: float = cfg.ALPHA) -> float:
    n = len(residuals)
    if n == 0:
        return np.nan
    level = cfg.conformal_quantile_level(n, alpha)
    return float(np.quantile(np.sort(residuals), level, method="higher"))


def global_conformal_quantile(cal_abs_resid: np.ndarray, alpha: float = cfg.ALPHA) -> float:
    return _empirical_quantile(cal_abs_resid, alpha)


def global_conformal_interval(point_pred: np.ndarray, q: float):
    return point_pred - q, point_pred + q


def mondrian_conformal_quantiles(
    cal_group: pd.Series, cal_abs_resid: np.ndarray, alpha: float = cfg.ALPHA,
    min_group: int = cfg.MONDRIAN_DEFAULT_MIN_GROUP,
):
    """Return dict: group_value -> conformal quantile, plus the global fallback quantile."""
    global_q = global_conformal_quantile(cal_abs_resid, alpha)
    df = pd.DataFrame({"group": cal_group.to_numpy(), "resid": cal_abs_resid})
    quantiles = {}
    for g, sub in df.groupby("group", observed=True):
        if len(sub) < min_group:
            quantiles[g] = global_q  # fixed Mondrian default: fall back to global
        else:
            quantiles[g] = _empirical_quantile(sub["resid"].to_numpy(), alpha)
    return quantiles, global_q


def mondrian_conformal_interval(point_pred: np.ndarray, test_group: pd.Series, quantiles: dict, global_q: float):
    q_arr = test_group.map(lambda g: quantiles.get(g, global_q)).to_numpy(dtype=float)
    return point_pred - q_arr, point_pred + q_arr


def quantile_gb_interval(lower_pred: np.ndarray, upper_pred: np.ndarray):
    lo = np.minimum(lower_pred, upper_pred)
    hi = np.maximum(lower_pred, upper_pred)
    return lo, hi


def gpr_interval(mean_pred: np.ndarray, std_pred: np.ndarray, alpha: float = cfg.ALPHA):
    from scipy import stats
    z = stats.norm.ppf(1 - alpha / 2)
    return mean_pred - z * std_pred, mean_pred + z * std_pred
