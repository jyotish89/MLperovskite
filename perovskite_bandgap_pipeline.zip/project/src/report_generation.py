"""Phase 6: methods draft + results summary, exported as Markdown and LaTeX,
including the mandatory validity caveat about conformal exchangeability."""
from __future__ import annotations
import sys
import json
import pandas as pd

sys.path.insert(0, str(__import__("pathlib").Path(__file__).resolve().parent))
import config as cfg

CAVEAT = (
    "**Validity caveat.** Split-conformal validity relies on exchangeability "
    "between calibration and test data. This assumption is violated for "
    "compositions containing a B-site, A-site, or X-site category unseen "
    "during calibration; in that regime the reported coverage guarantees do "
    "not extend, and the intervals carry no built-in warning flag for this "
    "failure mode. Users extrapolating to novel site chemistries should treat "
    "interval widths as indicative rather than guaranteed, and consult the "
    "LOBO and novelty-quartile results in this report before trusting an "
    "interval for an unfamiliar composition."
)


def fmt_pct(x):
    return f"{100*x:.1f}%" if pd.notna(x) else "n/a"


def build_markdown():
    with open(cfg.CACHE_DIR / "cleaning_report.json") as f:
        cleaning_report = json.load(f)
    with open(cfg.CACHE_DIR / "tuned_config.json") as f:
        tuned_config = json.load(f)
    with open(cfg.CACHE_DIR / "main_benchmark_meta.json") as f:
        bench_meta = json.load(f)
    with open(cfg.CACHE_DIR / "novelty_sensitivity.json") as f:
        novelty_sens = json.load(f)

    agg_df = pd.read_csv(cfg.TAB_DIR / "main_benchmark_aggregate.csv")
    lobo_agg = pd.read_csv(cfg.TAB_DIR / "lobo_aggregate.csv")
    mond_sens = pd.read_csv(cfg.TAB_DIR / "sensitivity_mondrian_threshold.csv")
    gpr_sens = pd.read_csv(cfg.TAB_DIR / "sensitivity_gpr_ladder.csv")

    global_row = agg_df[agg_df["method"] == "global_conformal"].iloc[0]

    md = []
    md.append("# Perovskite Band-Gap Uncertainty Quantification: Results Summary\n")
    md.append(
        "## Data\n\n"
        f"The master dataset ({cleaning_report['n_input_rows']:,} rows) was cleaned by removing "
        f"{cleaning_report['n_exact_duplicate_rows_removed']} literal exact-duplicate rows and "
        f"{cleaning_report['n_fully_missing_rows_removed']:,} rows lacking every site-identity and "
        "geometric descriptor (formula and calc_method were always present and never used to justify "
        f"exclusion). No implausible internal inconsistency was found between the derived descriptors "
        "(tolerance factor, octahedral factor, radius ratios) and r_A/r_B/r_X (max recomputation error "
        "~1e-15), so no additional records were excluded on that basis; out-of-typical-range values "
        f"were flagged ({cleaning_report['n_rows_flagged_out_of_physical_range']:,} rows) but retained. "
        f"This leaves {cleaning_report['n_output_rows']:,} rows: "
        f"{cleaning_report['n_low_fidelity_rows']:,} low-fidelity (calc_method outside the HSE06 family) "
        f"and {cleaning_report['n_high_fidelity_rows']:,} high-fidelity "
        f"({', '.join(cfg.HIGH_FIDELITY_METHODS)}), with "
        f"{cleaning_report['n_formulas_overlapping_between_pools']} formulas appearing in both pools.\n"
    )
    md.append(
        "## Model tuning\n\n"
        "A base HistGradientBoostingRegressor (MAE objective) and two pinball-loss quantile regressors "
        f"(alpha={cfg.QUANTILE_LOWER}, {cfg.QUANTILE_UPPER}) were tuned once on the complete low-fidelity "
        f"pool with formula-grouped 5-fold cross-validation and a {cfg.RANDOM_SEARCH_N_ITER}-iteration "
        "randomized search each; the selected configurations were reused, unmodified, throughout all "
        "downstream evaluation (see `tuned_config.json` and the model table for exact hyperparameters).\n"
    )
    md.append(
        "## Main benchmark (20 formula-disjoint calibration/test splits)\n\n"
        f"All four UQ methods were evaluated on {cfg.MAIN_N_SPLITS} independently seeded, "
        "formula-disjoint calibration/test partitions of the high-fidelity pool "
        f"({int(cfg.CAL_FRACTION*100)}% calibration / {int((1-cfg.CAL_FRACTION)*100)}% test). "
        f"Global split conformal achieved approximately {fmt_pct(global_row['coverage_mean'])} coverage "
        f"(95% bootstrap CI [{fmt_pct(global_row['coverage_boot_lo'])}, "
        f"{fmt_pct(global_row['coverage_boot_hi'])}]) against a {int((1-cfg.ALPHA)*100)}% nominal target -- "
        "close to nominal coverage, not unqualified 'reliable' coverage. "
        "Mondrian (B-site-conditional) conformal, direct quantile-GB intervals, and GPR intervals are "
        "compared in the benchmark table; quantile-GB intervals in particular substantially undercover "
        "relative to nominal, illustrating that uncalibrated pinball-loss bounds should not be read as "
        "valid prediction intervals on their own.\n"
    )
    md.append(
        "## Extrapolation (LOBO)\n\n"
        "Leave-one-site-out analyses (5 fixed seeds each, recalibrated global-conformal quantile per "
        "fold) show coverage degrading most for X-site extrapolation "
        f"({fmt_pct(lobo_agg.set_index('site_type').loc['X_site','coverage_mean'])}) relative to "
        f"A-site ({fmt_pct(lobo_agg.set_index('site_type').loc['A_site','coverage_mean'])}) and "
        f"B-site ({fmt_pct(lobo_agg.set_index('site_type').loc['B_site','coverage_mean'])}) extrapolation, "
        "consistent with X-site chemistry driving band-gap behavior in ways the calibration set does not "
        "fully anticipate when a wholly new X-site species is encountered.\n"
    )
    md.append(
        "## Novelty analysis\n\n"
        f"Ranking high-fidelity test rows into novelty quartiles by distance to the low-fidelity reference "
        f"distribution gives materially different rankings depending on distance metric: Euclidean and "
        f"Mahalanobis quartile assignments agree for only "
        f"{100*novelty_sens['quartile_agreement_rate']:.1f}% of rows (Spearman rank correlation "
        f"{novelty_sens['spearman_corr']:.2f} between the two raw distances). This is a genuine sensitivity "
        "finding: conclusions about which compositions are 'novel' should not be treated as robust to the "
        "choice of distance metric without further scrutiny.\n"
    )
    md.append(
        "## Sensitivity analyses\n\n"
        "Mondrian minimum-group thresholds of 5/10/15/20 were compared (see "
        "`sensitivity_mondrian_threshold.csv`); "
        "the GPR training-set ladder (500/1,000/2,000/4,000 low-fidelity rows) was evaluated on the full "
        "high-fidelity pool (see `sensitivity_gpr_ladder.csv`). No full-data GP was attempted. "
        f"{int((~gpr_sens['feasible']).sum())} ladder point(s) were marked infeasible where requested.\n"
    )
    md.append("## Validity caveat\n\n" + CAVEAT + "\n")

    text = "\n".join(md)
    with open(cfg.MD_DIR / "manuscript_summary.md", "w") as f:
        f.write(text)
    return text


def build_latex():
    md_text = (cfg.MD_DIR / "manuscript_summary.md").read_text()
    # minimal, dependency-free markdown -> latex conversion for headings/bold
    lines = []
    for line in md_text.splitlines():
        if line.startswith("# "):
            lines.append(r"\section{%s}" % line[2:])
        elif line.startswith("## "):
            lines.append(r"\subsection{%s}" % line[3:])
        else:
            line = line.replace("**", r"\textbf{", 1)
            while "**" in line:
                line = line.replace("**", "}", 1)
            lines.append(line)
    tex_body = "\n".join(lines)
    doc = (
        "\\documentclass{article}\n\\usepackage[margin=1in]{geometry}\n"
        "\\usepackage{booktabs}\n\\title{Perovskite Band-Gap Uncertainty Quantification}\n"
        "\\date{}\n\\begin{document}\n\\maketitle\n" + tex_body + "\n\\end{document}\n"
    )
    with open(cfg.TEX_DIR / "manuscript_summary.tex", "w") as f:
        f.write(doc)


def run():
    build_markdown()
    build_latex()
    print("Manuscript written to", cfg.MD_DIR / "manuscript_summary.md", "and", cfg.TEX_DIR / "manuscript_summary.tex")


if __name__ == "__main__":
    run()
