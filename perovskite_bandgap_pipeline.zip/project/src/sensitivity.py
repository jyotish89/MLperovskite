"""
Phase 5: sensitivity analyses.
  - Repeat the main 20-seed Mondrian-conformal benchmark for thresholds
    5 / 10 / 15 / 20 (fixed default elsewhere is 10).
  - Evaluate GPR coverage/width at 500 / 1000 / 2000 / 4000 low-fidelity
    training rows (a full-data GP is explicitly out of scope).
Infeasible configurations are marked explicitly rather than silently skipped
or substituted.
"""
from __future__ import annotations
import sys
import json
import numpy as np
import pandas as pd
from sklearn.model_selection import GroupShuffleSplit

sys.path.insert(0, str(__import__("pathlib").Path(__file__).resolve().parent))
import config as cfg
import preprocessing as pp
import models as mdl
import conformal as conf
import metrics_ci as mci


def mondrian_threshold_sensitivity(lf_df, hf_df, thresholds=cfg.MONDRIAN_SENSITIVITY_THRESHOLDS):
    lf_m = pp.to_model_frame(lf_df)
    hf_m = pp.to_model_frame(hf_df)
    lf_m, hf_m = pp.align_categories(lf_m, hf_m)
    tuned = mdl.load_tuned_config()
    base = mdl.build_base_model(tuned)
    X_lf, y_lf = pp.X_y(lf_m)
    base.fit(X_lf, y_lf)

    groups_all = hf_m[cfg.GROUP_KEY].to_numpy()
    rows = []
    for threshold in thresholds:
        per_seed = []
        for seed in cfg.MAIN_SEEDS:
            gss = GroupShuffleSplit(n_splits=1, test_size=1 - cfg.CAL_FRACTION, random_state=seed)
            cal_idx, test_idx = next(gss.split(hf_m, groups=groups_all))
            cal_df = hf_m.iloc[cal_idx].reset_index(drop=True)
            test_df = hf_m.iloc[test_idx].reset_index(drop=True)

            X_cal, y_cal = pp.X_y(cal_df)
            X_test, y_test = pp.X_y(test_df)
            base_cal_pred = base.predict(X_cal)
            base_test_pred = base.predict(X_test)
            cal_abs_resid = np.abs(y_cal - base_cal_pred)

            n_groups_below_threshold = int(
                (cal_df[cfg.MONDRIAN_GROUP_COL].value_counts() < threshold).sum()
            )
            mond_q, global_q = conf.mondrian_conformal_quantiles(
                cal_df[cfg.MONDRIAN_GROUP_COL], cal_abs_resid, min_group=threshold
            )
            lo, hi = conf.mondrian_conformal_interval(
                base_test_pred, test_df[cfg.MONDRIAN_GROUP_COL], mond_q, global_q
            )
            covered = mci.empirical_coverage(y_test, lo, hi)
            n = len(y_test)
            succ = int(covered.sum())
            p_hat, wlo, whi = mci.wilson_interval(succ, n)
            per_seed.append({
                "threshold": threshold, "seed": seed, "n_test": n,
                "coverage": p_hat, "mean_width": float((hi - lo).mean()),
                "n_calibration_groups_below_threshold": n_groups_below_threshold,
            })
        per_seed_df = pd.DataFrame(per_seed)
        cov_mean, cov_lo, cov_hi = mci.bootstrap_ci(per_seed_df["coverage"].to_numpy())
        w_mean, w_lo, w_hi = mci.bootstrap_ci(per_seed_df["mean_width"].to_numpy())
        rows.append({
            "mondrian_min_group_threshold": threshold,
            "coverage_mean": cov_mean, "coverage_boot_lo": cov_lo, "coverage_boot_hi": cov_hi,
            "width_mean": w_mean, "width_boot_lo": w_lo, "width_boot_hi": w_hi,
            "mean_n_groups_below_threshold": per_seed_df["n_calibration_groups_below_threshold"].mean(),
            "feasible": True,
        })
    return pd.DataFrame(rows)


def gpr_size_sensitivity(lf_df, hf_df, sizes=cfg.GPR_LADDER_SIZES):
    lf_m = pp.to_model_frame(lf_df)
    hf_m = pp.to_model_frame(hf_df)
    lf_m, hf_m = pp.align_categories(lf_m, hf_m)

    rows = []
    for size in sizes:
        if size > len(lf_m):
            rows.append({
                "gpr_training_rows_requested": size, "gpr_training_rows_used": None,
                "feasible": False, "reason": "requested size exceeds available low-fidelity rows",
            })
            continue
        rng = np.random.default_rng(cfg.GPR_SEED + size)  # documented, size-specific but fixed seed
        idx = rng.choice(len(lf_m), size=size, replace=False)
        sub = lf_m.iloc[idx]
        X_sub, y_sub = pp.X_y(sub)
        pipe = mdl.build_gpr_pipeline(seed=cfg.GPR_SEED)
        pipe.fit(X_sub, y_sub)

        # evaluate on the full high-fidelity pool (fixed, not re-split per size --
        # this ladder isolates the effect of training-set size only)
        X_hf, y_hf = pp.X_y(hf_m)
        mean_pred, std_pred = pipe.predict(X_hf, return_std=True)
        lo, hi = conf.gpr_interval(mean_pred, std_pred)
        covered = mci.empirical_coverage(y_hf, lo, hi)
        n = len(y_hf)
        succ = int(covered.sum())
        p_hat, wlo, whi = mci.wilson_interval(succ, n)
        rows.append({
            "gpr_training_rows_requested": size, "gpr_training_rows_used": size,
            "feasible": True,
            "coverage": p_hat, "coverage_wilson_lo": wlo, "coverage_wilson_hi": whi,
            "mean_width": float((hi - lo).mean()),
            "mean_predictive_std": float(std_pred.mean()),
        })
    return pd.DataFrame(rows)


def run(lf_df, hf_df, save=True):
    mond_df = mondrian_threshold_sensitivity(lf_df, hf_df)
    gpr_df = gpr_size_sensitivity(lf_df, hf_df)
    if save:
        mond_df.to_csv(cfg.TAB_DIR / "sensitivity_mondrian_threshold.csv", index=False)
        gpr_df.to_csv(cfg.TAB_DIR / "sensitivity_gpr_ladder.csv", index=False)
    return mond_df, gpr_df


if __name__ == "__main__":
    import data_validation as dv
    import fidelity as fid

    df_clean, _ = dv.run(save=False)
    lf, hf = fid.split(df_clean)
    mond_df, gpr_df = run(lf, hf)
    print(mond_df.to_string())
    print(gpr_df.to_string())
