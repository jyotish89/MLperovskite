"""
Phase 1: Validation and audit.

Loads the raw CSV, asserts schema, cleans according to the fixed rules:
  - remove only literal exact-copy rows (keep differing same-formula rows)
  - exclude rows that are "fully missing" (every site + geometric descriptor
    column is NaN) -- these carry no usable feature information
  - never silently substitute / fabricate values
  - fail loudly if required columns/formulas are absent or if the specified
    HSE06 high-fidelity methods produce zero matches
Persists an auditable cleaning report (row IDs retained/excluded, formula
overlap between fidelity pools, physical-range flag counts).
"""
from __future__ import annotations
import json
import sys
import pandas as pd
import numpy as np

sys.path.insert(0, str(__import__("pathlib").Path(__file__).resolve().parent))
import config as cfg


class SchemaError(RuntimeError):
    pass


def load_raw(path=cfg.RAW_CSV) -> pd.DataFrame:
    df = pd.read_csv(path)
    missing_cols = [c for c in cfg.REQUIRED_COLUMNS if c not in df.columns]
    if missing_cols:
        raise SchemaError(f"Required columns absent from input: {missing_cols}")
    if df["formula"].isna().any():
        raise SchemaError(
            f"{df['formula'].isna().sum()} rows have no formula; formulas are "
            "required for grouped CV/splits and cannot be silently dropped without audit."
        )
    return df


def assert_high_fidelity_present(df: pd.DataFrame) -> pd.DataFrame:
    hf = df[df["calc_method"].isin(cfg.HIGH_FIDELITY_METHODS)]
    if len(hf) == 0:
        raise SchemaError(
            f"Zero rows matched the specified HSE06 high-fidelity methods "
            f"{cfg.HIGH_FIDELITY_METHODS}. Refusing to proceed silently."
        )
    return hf


def flag_physical_ranges(df: pd.DataFrame) -> pd.DataFrame:
    """Add boolean flag columns; never used to exclude rows automatically."""
    flags = pd.DataFrame(index=df.index)
    for col, (lo, hi) in cfg.PHYSICAL_RANGE_BOUNDS.items():
        flags[f"flag_out_of_range__{col}"] = ~df[col].between(lo, hi) & df[col].notna()
    flags["flag_any_out_of_range"] = flags.filter(like="flag_out_of_range__").any(axis=1)
    return flags


def clean(df: pd.DataFrame) -> tuple[pd.DataFrame, dict]:
    report = {}
    df = df.copy()
    df["row_id"] = np.arange(len(df))

    n0 = len(df)

    # 1) remove only literal exact-copy rows (all columns identical, row_id excluded)
    compare_cols = [c for c in df.columns if c != "row_id"]
    exact_dup_mask = df.duplicated(subset=compare_cols, keep="first")
    exact_dups = df.loc[exact_dup_mask, "row_id"].tolist()
    df_after_dedup = df.loc[~exact_dup_mask].copy()
    report["n_input_rows"] = n0
    report["n_exact_duplicate_rows_removed"] = int(exact_dup_mask.sum())
    report["exact_duplicate_row_ids"] = exact_dups

    # 2) exclude fully-missing rows (site + all numeric descriptors all NaN)
    descriptor_cols = cfg.CATEGORICAL_FEATURES + cfg.NUMERIC_FEATURES
    fully_missing_mask = df_after_dedup[descriptor_cols].isna().all(axis=1)
    fully_missing_ids = df_after_dedup.loc[fully_missing_mask, "row_id"].tolist()
    df_clean = df_after_dedup.loc[~fully_missing_mask].copy()
    report["n_fully_missing_rows_removed"] = int(fully_missing_mask.sum())
    report["fully_missing_row_ids_sample"] = fully_missing_ids[:50]
    report["fully_missing_row_ids_count"] = len(fully_missing_ids)

    # Sanity: any residual rows with a subset of descriptors missing keep their
    # NaNs -- HistGradientBoosting natively supports missing numeric values,
    # and their categorical site identities are complete (not "unreconcilable").
    partial_missing = df_clean[descriptor_cols].isna().any(axis=1).sum()
    report["n_rows_with_partial_missing_descriptors_retained"] = int(partial_missing)

    # 3) physical range flags (retained for audit; not used to exclude)
    flags = flag_physical_ranges(df_clean)
    df_clean = pd.concat([df_clean, flags], axis=1)
    report["n_rows_flagged_out_of_physical_range"] = int(flags["flag_any_out_of_range"].sum())
    report["physical_range_bounds"] = cfg.PHYSICAL_RANGE_BOUNDS

    # 4) internal consistency check of derived descriptors vs r_A/r_B/r_X
    #    (documented, not used to exclude -- verified deterministic/consistent)
    complete = df_clean.dropna(subset=cfg.NUMERIC_FEATURES)
    if len(complete) > 0:
        rA, rB, rX = complete["r_A (ang)"], complete["r_B (ang)"], complete["r_X (ang)"]
        t_calc = (rA + rX) / (np.sqrt(2) * (rB + rX))
        mu_calc = rB / rX
        rArX_calc = rA / rX
        rBrX_calc = rB / rX
        report["max_abs_error_tolerance_factor_recompute"] = float(
            (t_calc - complete["tolerance_factor_t"]).abs().max()
        )
        report["max_abs_error_octahedral_factor_recompute"] = float(
            (mu_calc - complete["octahedral_factor_mu"]).abs().max()
        )
        report["max_abs_error_radius_ratio_rA_rX_recompute"] = float(
            (rArX_calc - complete["radius_ratio_rA_rX"]).abs().max()
        )
        report["max_abs_error_radius_ratio_rB_rX_recompute"] = float(
            (rBrX_calc - complete["radius_ratio_rB_rX"]).abs().max()
        )

    report["n_output_rows"] = len(df_clean)

    # 5) fidelity pool summary + formula overlap
    hf = df_clean[df_clean["calc_method"].isin(cfg.HIGH_FIDELITY_METHODS)]
    lf = df_clean[~df_clean["calc_method"].isin(cfg.HIGH_FIDELITY_METHODS)]
    if len(hf) == 0:
        raise SchemaError(
            "Zero high-fidelity (HSE06-family) rows remain after cleaning. Aborting."
        )
    overlap = set(hf["formula"]).intersection(set(lf["formula"]))
    report["n_high_fidelity_rows"] = len(hf)
    report["n_low_fidelity_rows"] = len(lf)
    report["n_high_fidelity_unique_formulas"] = hf["formula"].nunique()
    report["n_low_fidelity_unique_formulas"] = lf["formula"].nunique()
    report["n_formulas_overlapping_between_pools"] = len(overlap)
    report["calc_method_counts"] = df_clean["calc_method"].value_counts().to_dict()
    report["dataset_source_counts"] = df_clean["dataset_source"].value_counts().to_dict()

    # same-formula, differing-record diagnostics (retained, not aggregated)
    dup_formula_counts = df_clean["formula"].value_counts()
    report["n_formulas_with_multiple_retained_rows"] = int((dup_formula_counts > 1).sum())

    return df_clean, report


def run(save=True):
    df_raw = load_raw()
    assert_high_fidelity_present(df_raw)
    df_clean, report = clean(df_raw)

    if save:
        df_clean.to_parquet(cfg.CACHE_DIR / "clean_data.parquet", index=False)
        with open(cfg.CACHE_DIR / "cleaning_report.json", "w") as f:
            json.dump(report, f, indent=2, default=str)
        with open(cfg.TAB_DIR / "cleaning_report.md", "w") as f:
            f.write("# Data Validation & Cleaning Audit Report\n\n")
            for k, v in report.items():
                if isinstance(v, (dict, list)) and len(str(v)) > 400:
                    f.write(f"- **{k}**: (see cleaning_report.json)\n")
                else:
                    f.write(f"- **{k}**: {v}\n")
    return df_clean, report


if __name__ == "__main__":
    df_clean, report = run()
    print(json.dumps({k: v for k, v in report.items() if not isinstance(v, list)}, indent=2, default=str))
