"""
Phase 2 (part 1): categorical handling + numeric validation for the ten
requested features (3 categorical site identities + 7 numeric descriptors).

HistGradientBoostingRegressor (sklearn >=1.3) natively supports:
  - pandas 'category' dtype columns via categorical_features='from_dtype'
  - missing numeric values (NaN) without imputation
so we simply cast categorical columns and leave numeric NaNs untouched.
"""
from __future__ import annotations
import sys
import pandas as pd

sys.path.insert(0, str(__import__("pathlib").Path(__file__).resolve().parent))
import config as cfg


def to_model_frame(df: pd.DataFrame) -> pd.DataFrame:
    """Return a copy with FEATURES cast appropriately for HGB native handling."""
    out = df.copy()
    for c in cfg.CATEGORICAL_FEATURES:
        out[c] = out[c].astype("category")
    for c in cfg.NUMERIC_FEATURES:
        out[c] = pd.to_numeric(out[c], errors="raise")
    return out


def align_categories(train_df: pd.DataFrame, *other_dfs: pd.DataFrame):
    """
    Ensure categorical columns share the same category set (union) across
    train/other frames so HGB's categorical encoding is consistent and unseen
    categories at prediction time are representable (as NaN-like unknown).
    """
    frames = [train_df] + list(other_dfs)
    for c in cfg.CATEGORICAL_FEATURES:
        union = pd.api.types.union_categoricals(
            [f[c].astype("category") for f in frames]
        ).categories
        for f in frames:
            f[c] = f[c].astype(pd.CategoricalDtype(categories=union))
    return frames


def X_y(df: pd.DataFrame):
    X = df[cfg.FEATURES]
    y = df[cfg.TARGET].to_numpy()
    return X, y
