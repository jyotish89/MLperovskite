"""
Phase 3: UQ benchmark over 20 formula-disjoint calibration/test splits of the
high-fidelity (HSE06-family) pool. Low-fidelity models are fit once and reused
across all 20 repetitions; only the calibration/test partition changes.

Four UQ methods per repetition: global conformal, Mondrian (B-site) conformal,
quantile-GB, and GPR (fit once on a fixed 4000-row low-fidelity subsample,
reused across seeds -- consistent with "do not attempt a full-data GP").
"""
from __future__ import annotations
import sys
import json
import numpy as np
import pandas as pd
from sklearn.model_selection import GroupShuffleSplit

sys.path.insert(0, str(__import__("pathlib").Path(__file__).resolve().parent))
import config as cfg
import preprocessing as pp
import models as mdl
import conformal as conf
import metrics_ci as mci


def fit_low_fidelity_models(lf_df: pd.DataFrame, hf_df: pd.DataFrame):
    """Fit base + quantile models on the full low-fidelity pool (once).
    Categories are aligned across low- and high-fidelity frames so unseen
    site identities at prediction time are handled consistently."""
    lf_m = pp.to_model_frame(lf_df)
    hf_m = pp.to_model_frame(hf_df)
    lf_m, hf_m = pp.align_categories(lf_m, hf_m)

    X_lf, y_lf = pp.X_y(lf_m)
    base = mdl.build_base_model()
    base.fit(X_lf, y_lf)
    q_lo = mdl.build_quantile_model("quantile_lower")
    q_lo.fit(X_lf, y_lf)
    q_hi = mdl.build_quantile_model("quantile_upper")
    q_hi.fit(X_lf, y_lf)
    return base, q_lo, q_hi, lf_m, hf_m


def fit_gpr_once(lf_m: pd.DataFrame, size=cfg.GPR_LADDER_SIZES[-1], seed=cfg.GPR_SEED):
    rng = np.random.default_rng(seed)
    n = min(size, len(lf_m))
    idx = rng.choice(len(lf_m), size=n, replace=False)
    sub = lf_m.iloc[idx]
    X_sub, y_sub = pp.X_y(sub)
    pipe = mdl.build_gpr_pipeline(seed=seed)
    pipe.fit(X_sub, y_sub)
    return pipe, n


def run_one_seed(seed, hf_m, base, q_lo, q_hi, gpr_pipe):
    groups = hf_m[cfg.GROUP_KEY].to_numpy()
    gss = GroupShuffleSplit(n_splits=1, test_size=1 - cfg.CAL_FRACTION, random_state=seed)
    cal_idx, test_idx = next(gss.split(hf_m, groups=groups))
    cal_df = hf_m.iloc[cal_idx].reset_index(drop=True)
    test_df = hf_m.iloc[test_idx].reset_index(drop=True)

    # acceptance check: no calibration/test formula overlap
    overlap = set(cal_df[cfg.GROUP_KEY]) & set(test_df[cfg.GROUP_KEY])
    assert len(overlap) == 0, f"seed {seed}: calibration/test formula overlap detected: {overlap}"

    X_cal, y_cal = pp.X_y(cal_df)
    X_test, y_test = pp.X_y(test_df)

    base_cal_pred = base.predict(X_cal)
    base_test_pred = base.predict(X_test)
    cal_abs_resid = np.abs(y_cal - base_cal_pred)

    rows = []

    # 1) global conformal
    gq = conf.global_conformal_quantile(cal_abs_resid)
    lo, hi = conf.global_conformal_interval(base_test_pred, gq)
    rows.append(_pack(seed, "global_conformal", test_df, y_test, base_test_pred, lo, hi))

    # 2) Mondrian conformal (grouped by B_site)
    mond_q, global_q = conf.mondrian_conformal_quantiles(
        cal_df[cfg.MONDRIAN_GROUP_COL], cal_abs_resid
    )
    lo, hi = conf.mondrian_conformal_interval(base_test_pred, test_df[cfg.MONDRIAN_GROUP_COL], mond_q, global_q)
    rows.append(_pack(seed, "mondrian_conformal", test_df, y_test, base_test_pred, lo, hi))

    # 3) quantile-GB
    lo_pred = q_lo.predict(X_test)
    hi_pred = q_hi.predict(X_test)
    lo, hi = conf.quantile_gb_interval(lo_pred, hi_pred)
    rows.append(_pack(seed, "quantile_gb", test_df, y_test, base_test_pred, lo, hi))

    # 4) GPR
    gpr_mean, gpr_std = gpr_pipe.predict(X_test, return_std=True)
    lo, hi = conf.gpr_interval(gpr_mean, gpr_std)
    rows.append(_pack(seed, "gpr", test_df, y_test, gpr_mean, lo, hi))

    return pd.concat(rows, ignore_index=True)


def _pack(seed, method, test_df, y_test, point_pred, lo, hi):
    covered = mci.empirical_coverage(y_test, lo, hi)
    return pd.DataFrame({
        "seed": seed, "method": method, "row_id": test_df["row_id"].to_numpy(),
        "formula": test_df["formula"].to_numpy(), "B_site": test_df["B_site"].to_numpy(),
        "y_true": y_test, "point_pred": point_pred, "lower": lo, "upper": hi,
        "width": hi - lo, "covered": covered,
    })


def summarize(row_level: pd.DataFrame):
    """Per-seed-per-method coverage (Wilson CI) and per-method aggregate
    coverage/width across seeds (bootstrap CI)."""
    per_seed = []
    for (seed, method), sub in row_level.groupby(["seed", "method"]):
        n = len(sub)
        succ = int(sub["covered"].sum())
        p_hat, lo, hi = mci.wilson_interval(succ, n)
        per_seed.append({
            "seed": seed, "method": method, "n_test": n, "coverage": p_hat,
            "coverage_wilson_lo": lo, "coverage_wilson_hi": hi,
            "mean_width": sub["width"].mean(),
        })
    per_seed_df = pd.DataFrame(per_seed)

    agg = []
    for method, sub in per_seed_df.groupby("method"):
        cov_mean, cov_lo, cov_hi = mci.bootstrap_ci(sub["coverage"].to_numpy())
        w_mean, w_lo, w_hi = mci.bootstrap_ci(sub["mean_width"].to_numpy())
        agg.append({
            "method": method, "n_seeds": len(sub),
            "coverage_mean": cov_mean, "coverage_boot_lo": cov_lo, "coverage_boot_hi": cov_hi,
            "width_mean": w_mean, "width_boot_lo": w_lo, "width_boot_hi": w_hi,
        })
    agg_df = pd.DataFrame(agg)
    return per_seed_df, agg_df


def run(lf_df: pd.DataFrame, hf_df: pd.DataFrame, save=True):
    base, q_lo, q_hi, lf_m, hf_m = fit_low_fidelity_models(lf_df, hf_df)
    gpr_pipe, gpr_n = fit_gpr_once(lf_m)

    all_rows = []
    for seed in cfg.MAIN_SEEDS:
        all_rows.append(run_one_seed(seed, hf_m, base, q_lo, q_hi, gpr_pipe))
    row_level = pd.concat(all_rows, ignore_index=True)
    per_seed_df, agg_df = summarize(row_level)

    if save:
        row_level.to_csv(cfg.CACHE_DIR / "main_benchmark_row_level.csv", index=False)
        per_seed_df.to_csv(cfg.CACHE_DIR / "main_benchmark_per_seed.csv", index=False)
        agg_df.to_csv(cfg.TAB_DIR / "main_benchmark_aggregate.csv", index=False)
        with open(cfg.CACHE_DIR / "main_benchmark_meta.json", "w") as f:
            json.dump({
                "n_seeds": cfg.MAIN_N_SPLITS, "seeds": cfg.MAIN_SEEDS,
                "cal_fraction": cfg.CAL_FRACTION, "gpr_training_rows": gpr_n,
                "mondrian_group_col": cfg.MONDRIAN_GROUP_COL,
                "mondrian_min_group": cfg.MONDRIAN_DEFAULT_MIN_GROUP,
                "conformal_alpha": cfg.ALPHA,
            }, f, indent=2)
    return row_level, per_seed_df, agg_df


if __name__ == "__main__":
    import data_validation as dv
    import fidelity as fid

    df_clean, _ = dv.run(save=False)
    lf, hf = fid.split(df_clean)
    row_level, per_seed_df, agg_df = run(lf, hf)
    print(agg_df.to_string())
