"""Split cleaned data into low-fidelity (tuning/training pool) and
high-fidelity (HSE06-family) calibration/test pool."""
from __future__ import annotations
import sys
import pandas as pd

sys.path.insert(0, str(__import__("pathlib").Path(__file__).resolve().parent))
import config as cfg


def split(df: pd.DataFrame):
    is_hf = df["calc_method"].isin(cfg.HIGH_FIDELITY_METHODS)
    hf = df.loc[is_hf].reset_index(drop=True)
    lf = df.loc[~is_hf].reset_index(drop=True)
    if len(hf) == 0:
        raise RuntimeError("Zero high-fidelity rows -- aborting (no silent fallback).")
    if len(lf) == 0:
        raise RuntimeError("Zero low-fidelity rows -- aborting (no silent fallback).")
    return lf, hf
