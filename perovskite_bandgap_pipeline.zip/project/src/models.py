"""Model construction helpers: tuned HistGradientBoosting regressors and a
Gaussian Process regressor used for the GPR sensitivity ladder."""
from __future__ import annotations
import sys
import json
import numpy as np
import pandas as pd
from sklearn.ensemble import HistGradientBoostingRegressor
from sklearn.gaussian_process import GaussianProcessRegressor
from sklearn.gaussian_process.kernels import RBF, WhiteKernel, ConstantKernel
from sklearn.preprocessing import StandardScaler, OneHotEncoder
from sklearn.compose import ColumnTransformer
from sklearn.pipeline import Pipeline

sys.path.insert(0, str(__import__("pathlib").Path(__file__).resolve().parent))
import config as cfg


def load_tuned_config():
    with open(cfg.CACHE_DIR / "tuned_config.json") as f:
        return json.load(f)


def build_base_model(tuned=None, seed=cfg.TUNING_SEED):
    tuned = tuned or load_tuned_config()
    params = tuned["base"]["best_params"]
    return HistGradientBoostingRegressor(
        loss="squared_error", categorical_features="from_dtype",
        random_state=seed, **params,
    )


def build_quantile_model(which: str, tuned=None, seed=cfg.TUNING_SEED):
    tuned = tuned or load_tuned_config()
    assert which in ("quantile_lower", "quantile_upper")
    q = tuned[which]["quantile"]
    params = tuned[which]["best_params"]
    return HistGradientBoostingRegressor(
        loss="quantile", quantile=q, categorical_features="from_dtype",
        random_state=seed, **params,
    )


def build_gpr_pipeline(seed=cfg.GPR_SEED):
    """
    GPR needs fully-numeric input: one-hot encode categorical site identities,
    standardize numeric descriptors, median-impute any remaining NaNs (GPR has
    no native missing-value support, unlike HGB).
    """
    from sklearn.impute import SimpleImputer

    numeric_pipe = Pipeline([
        ("impute", SimpleImputer(strategy="median")),
        ("scale", StandardScaler()),
    ])
    cat_pipe = Pipeline([
        ("impute", SimpleImputer(strategy="most_frequent")),
        ("ohe", OneHotEncoder(handle_unknown="ignore", sparse_output=False)),
    ])
    pre = ColumnTransformer([
        ("num", numeric_pipe, cfg.NUMERIC_FEATURES),
        ("cat", cat_pipe, cfg.CATEGORICAL_FEATURES),
    ])
    kernel = ConstantKernel(1.0, (1e-3, 1e3)) * RBF(
        length_scale=1.0, length_scale_bounds=(1e-2, 1e2)
    ) + WhiteKernel(noise_level=0.1, noise_level_bounds=(1e-5, 1e1))
    gpr = GaussianProcessRegressor(
        kernel=kernel, normalize_y=True, random_state=seed, n_restarts_optimizer=1,
    )
    return Pipeline([("pre", pre), ("gpr", gpr)])
