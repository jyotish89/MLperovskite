"""
Phase 4: extrapolation and novelty.

LOBO design note (documented for auditability -- the brief fixes the seed
count/discipline but not the exact resampling protocol): for each held-out
site value, the calibration pool is every remaining high-fidelity row (whose
formulas are automatically disjoint from the held-out group's formulas,
since a formula's A/B/X identity is fixed). To keep calibration-set scale
comparable to the main benchmark (where calibration is ~50% of the HF pool)
and to give the "five fixed seeds" genuine meaning, each seed draws an
independent random subsample of that remaining pool (capped at the main
benchmark's target calibration size) before recomputing the global conformal
quantile. This is recalibration, not reuse of the main benchmark's quantile.

Novelty quartiles: standardized numeric + one-hot categorical distance of each
high-fidelity test row (from the pooled main-benchmark global-conformal
results) to the low-fidelity reference distribution, using both Euclidean and
Mahalanobis distance as a sensitivity comparison.
"""
from __future__ import annotations
import sys
import json
import numpy as np
import pandas as pd
from sklearn.preprocessing import StandardScaler, OneHotEncoder
from sklearn.compose import ColumnTransformer
from sklearn.impute import SimpleImputer
from sklearn.pipeline import Pipeline
from sklearn.covariance import LedoitWolf

sys.path.insert(0, str(__import__("pathlib").Path(__file__).resolve().parent))
import config as cfg
import preprocessing as pp
import conformal as conf
import metrics_ci as mci

SITE_COLS = ["A_site", "B_site", "X_site"]


def run_lobo_for_site(site_col, hf_m, base, target_cal_size, min_test_rows=3):
    records = []
    values = hf_m[site_col].dropna().unique().tolist()
    for val in values:
        test_mask = hf_m[site_col] == val
        n_test = int(test_mask.sum())
        if n_test < min_test_rows:
            continue  # not enough held-out support to evaluate meaningfully
        test_df = hf_m.loc[test_mask].reset_index(drop=True)
        remaining = hf_m.loc[~test_mask].reset_index(drop=True)
        if len(remaining) == 0:
            continue

        X_test, y_test = pp.X_y(test_df)
        base_test_pred = base.predict(X_test)

        for seed in cfg.LOBO_SEEDS:
            rng = np.random.default_rng(seed)
            cal_size = min(len(remaining), target_cal_size)
            cal_idx = rng.choice(len(remaining), size=cal_size, replace=False)
            cal_df = remaining.iloc[cal_idx]
            X_cal, y_cal = pp.X_y(cal_df)
            base_cal_pred = base.predict(X_cal)
            cal_abs_resid = np.abs(y_cal - base_cal_pred)
            q = conf.global_conformal_quantile(cal_abs_resid)
            lo, hi = conf.global_conformal_interval(base_test_pred, q)
            covered = mci.empirical_coverage(y_test, lo, hi)
            succ = int(covered.sum())
            p_hat, wlo, whi = mci.wilson_interval(succ, n_test)
            records.append({
                "site_type": site_col, "held_out_value": val, "seed": seed,
                "n_test": n_test, "n_calibration": cal_size,
                "coverage": p_hat, "coverage_wilson_lo": wlo, "coverage_wilson_hi": whi,
                "mean_width": float((hi - lo).mean()),
                "conformal_quantile": q,
            })
    return pd.DataFrame(records)


def run_lobo(hf_m, base, target_cal_size):
    frames = [run_lobo_for_site(c, hf_m, base, target_cal_size) for c in SITE_COLS]
    detail = pd.concat(frames, ignore_index=True) if frames else pd.DataFrame()

    agg = []
    if len(detail):
        for site_type, sub in detail.groupby("site_type"):
            cov_mean, cov_lo, cov_hi = mci.bootstrap_ci(sub["coverage"].to_numpy())
            w_mean, w_lo, w_hi = mci.bootstrap_ci(sub["mean_width"].to_numpy())
            agg.append({
                "site_type": site_type, "n_held_out_values": sub["held_out_value"].nunique(),
                "n_records": len(sub),
                "coverage_mean": cov_mean, "coverage_boot_lo": cov_lo, "coverage_boot_hi": cov_hi,
                "width_mean": w_mean, "width_boot_lo": w_lo, "width_boot_hi": w_hi,
            })
    agg_df = pd.DataFrame(agg)
    return detail, agg_df


def _build_reference_transform(lf_m: pd.DataFrame):
    numeric_pipe = Pipeline([("impute", SimpleImputer(strategy="median")), ("scale", StandardScaler())])
    cat_pipe = Pipeline([
        ("impute", SimpleImputer(strategy="most_frequent")),
        ("ohe", OneHotEncoder(handle_unknown="ignore", sparse_output=False)),
    ])
    pre = ColumnTransformer([
        ("num", numeric_pipe, cfg.NUMERIC_FEATURES),
        ("cat", cat_pipe, cfg.CATEGORICAL_FEATURES),
    ])
    Z_lf = pre.fit_transform(lf_m[cfg.FEATURES])
    return pre, Z_lf


def novelty_analysis(lf_m: pd.DataFrame, main_row_level: pd.DataFrame, hf_m: pd.DataFrame):
    """Distance of each high-fidelity test row (global_conformal method rows,
    de-duplicated across seeds by row_id) to the low-fidelity reference pool."""
    pre, Z_lf = _build_reference_transform(lf_m)
    centroid = Z_lf.mean(axis=0)

    # regularized covariance for a stable Mahalanobis distance
    cov_est = LedoitWolf().fit(Z_lf)
    cov_inv = cov_est.get_precision()

    test_rows = (
        main_row_level[main_row_level["method"] == "global_conformal"]
        .drop_duplicates(subset="row_id")
        [["row_id", "seed", "method", "y_true", "point_pred", "lower", "upper", "width", "covered"]]
        .merge(hf_m[["row_id"] + cfg.FEATURES], on="row_id", how="left")
    )
    Z_test = pre.transform(test_rows[cfg.FEATURES])

    euclid = np.linalg.norm(Z_test - centroid, axis=1)
    diff = Z_test - centroid
    mahal = np.sqrt(np.einsum("ij,jk,ik->i", diff, cov_inv, diff))

    test_rows = test_rows.copy()
    test_rows["euclidean_distance"] = euclid
    test_rows["mahalanobis_distance"] = mahal

    def quartile_bin(series):
        try:
            return pd.qcut(series, cfg.NOVELTY_N_QUARTILES, labels=False, duplicates="drop") + 1
        except ValueError:
            return pd.Series(np.ones(len(series), dtype=int), index=series.index)

    test_rows["euclidean_quartile"] = quartile_bin(test_rows["euclidean_distance"])
    test_rows["mahalanobis_quartile"] = quartile_bin(test_rows["mahalanobis_distance"])

    def summarize_by_quartile(qcol):
        out = []
        for q, sub in test_rows.groupby(qcol, observed=True):
            n = len(sub)
            succ = int(sub["covered"].sum())
            p_hat, lo, hi = mci.wilson_interval(succ, n)
            out.append({
                "distance_metric": qcol, "quartile": int(q), "n_test": n,
                "coverage": p_hat, "coverage_wilson_lo": lo, "coverage_wilson_hi": hi,
                "mean_width": sub["width"].mean(),
                "mean_distance": sub[qcol.replace("_quartile", "_distance")].mean(),
            })
        return pd.DataFrame(out).sort_values("quartile")

    euclid_summary = summarize_by_quartile("euclidean_quartile")
    mahal_summary = summarize_by_quartile("mahalanobis_quartile")

    agreement = float(
        (test_rows["euclidean_quartile"] == test_rows["mahalanobis_quartile"]).mean()
    )
    corr = float(test_rows["euclidean_distance"].corr(test_rows["mahalanobis_distance"], method="spearman"))

    return test_rows, euclid_summary, mahal_summary, {"quartile_agreement_rate": agreement, "spearman_corr": corr}


def run(lf_df, hf_df, main_row_level: pd.DataFrame, save=True):
    import fidelity as fid  # noqa
    lf_m = pp.to_model_frame(lf_df)
    hf_m = pp.to_model_frame(hf_df)
    lf_m, hf_m = pp.align_categories(lf_m, hf_m)

    import models as mdl
    tuned = mdl.load_tuned_config()
    base = mdl.build_base_model(tuned)
    X_lf, y_lf = pp.X_y(lf_m)
    base.fit(X_lf, y_lf)

    target_cal_size = round(cfg.CAL_FRACTION * len(hf_m))
    lobo_detail, lobo_agg = run_lobo(hf_m, base, target_cal_size)

    test_rows, euclid_summary, mahal_summary, sens = novelty_analysis(lf_m, main_row_level, hf_m)

    if save:
        lobo_detail.to_csv(cfg.CACHE_DIR / "lobo_detail.csv", index=False)
        lobo_agg.to_csv(cfg.TAB_DIR / "lobo_aggregate.csv", index=False)
        euclid_summary.to_csv(cfg.TAB_DIR / "novelty_euclidean.csv", index=False)
        mahal_summary.to_csv(cfg.TAB_DIR / "novelty_mahalanobis.csv", index=False)
        test_rows.drop(columns=cfg.FEATURES, errors="ignore").to_csv(
            cfg.CACHE_DIR / "novelty_row_level.csv", index=False
        )
        with open(cfg.CACHE_DIR / "novelty_sensitivity.json", "w") as f:
            json.dump(sens, f, indent=2)

    return lobo_detail, lobo_agg, euclid_summary, mahal_summary, sens


if __name__ == "__main__":
    import data_validation as dv
    import fidelity as fid

    df_clean, _ = dv.run(save=False)
    lf, hf = fid.split(df_clean)
    main_row_level = pd.read_csv(cfg.CACHE_DIR / "main_benchmark_row_level.csv")
    lobo_detail, lobo_agg, euclid_summary, mahal_summary, sens = run(lf, hf, main_row_level)
    print(lobo_agg.to_string())
    print(euclid_summary.to_string())
    print(mahal_summary.to_string())
    print(sens)
