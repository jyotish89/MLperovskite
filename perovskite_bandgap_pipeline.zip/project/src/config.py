"""
Central configuration for the perovskite band-gap UQ pipeline.
All fixed scientific decisions live here so every script/module agrees.
"""
from pathlib import Path
import numpy as np

# ---------------------------------------------------------------- paths ----
ROOT = Path(__file__).resolve().parents[1]
DATA_DIR = ROOT / "data"
RESULTS_DIR = ROOT / "results"
FIG_DIR = RESULTS_DIR / "figures"
TAB_DIR = RESULTS_DIR / "tables"
MD_DIR = RESULTS_DIR / "markdown"
TEX_DIR = RESULTS_DIR / "latex"
CACHE_DIR = ROOT / "data" / "checkpoints"
for d in [FIG_DIR, TAB_DIR, MD_DIR, TEX_DIR, CACHE_DIR]:
    d.mkdir(parents=True, exist_ok=True)

RAW_CSV = DATA_DIR / "master_composition_bandgap.csv"

# ------------------------------------------------------------- schema ----
REQUIRED_COLUMNS = [
    "dataset_source", "formula", "A_site", "B_site", "X_site",
    "band_gap (eV)", "calc_method",
    "r_A (ang)", "r_B (ang)", "r_X (ang)",
    "tolerance_factor_t", "octahedral_factor_mu",
    "radius_ratio_rA_rX", "radius_ratio_rB_rX",
]

TARGET = "band_gap (eV)"
GROUP_KEY = "formula"

CATEGORICAL_FEATURES = ["A_site", "B_site", "X_site"]
NUMERIC_FEATURES = [
    "r_A (ang)", "r_B (ang)", "r_X (ang)",
    "tolerance_factor_t", "octahedral_factor_mu",
    "radius_ratio_rA_rX", "radius_ratio_rB_rX",
]
# The ten requested features (3 categorical site identities + 7 numeric descriptors)
FEATURES = CATEGORICAL_FEATURES + NUMERIC_FEATURES
assert len(FEATURES) == 10

# ----------------------------------------------------- fidelity pools ----
# High-fidelity = the specified HSE06-family methods. Anything else is low-fidelity.
HIGH_FIDELITY_METHODS = [
    "DFT-HSE06 (relaxed)",
    "DFT-HSE06+SOC (relaxed)",
    "DFT-HSE06+SOC (on PBE geometry)",
]

# --------------------------------------------------- physical-range flags --
# Flags only (never used to silently exclude rows); documented in the audit report.
PHYSICAL_RANGE_BOUNDS = {
    "tolerance_factor_t": (0.70, 1.10),
    "octahedral_factor_mu": (0.40, 0.90),
    "r_A (ang)": (0.0, 3.0),
    "r_B (ang)": (0.0, 3.0),
    "r_X (ang)": (0.0, 3.0),
}

# ------------------------------------------------------------- seeds ----
MAIN_N_SPLITS = 20
MAIN_SEEDS = list(range(1000, 1000 + MAIN_N_SPLITS))  # 20 seeded splits, documented
LOBO_SEEDS = [2001, 2002, 2003, 2004, 2005]            # 5 fixed, documented LOBO seeds
TUNING_SEED = 42
GPR_SEED = 777

CAL_FRACTION = 0.5  # formula-disjoint calibration/test split fraction on high-fidelity pool

# ------------------------------------------------------- conformal UQ ----
ALPHA = 0.05  # 95% nominal target


def conformal_quantile_level(n: int, alpha: float = ALPHA) -> float:
    """Fixed conformal quantile convention: ceil((n+1)(1-alpha))/n, capped at 1.0."""
    level = np.ceil((n + 1) * (1 - alpha)) / n
    return float(min(level, 1.0))


MONDRIAN_DEFAULT_MIN_GROUP = 10   # fixed default: groups with < 10 cal rows use global quantile
MONDRIAN_GROUP_COL = "B_site"
MONDRIAN_SENSITIVITY_THRESHOLDS = [5, 10, 15, 20]

# ------------------------------------------------------ GPR sensitivity ----
GPR_LADDER_SIZES = [500, 1000, 2000, 4000]

# --------------------------------------------------------- tuning ----
CV_N_SPLITS = 5
RANDOM_SEARCH_N_ITER = 40

HGB_BASE_PARAM_DIST = {
    "max_iter": [100, 150, 200, 300, 400, 500],
    "max_leaf_nodes": [15, 31, 63, 127],
    "max_depth": [None, 3, 5, 8, 12],
    "learning_rate": [0.02, 0.05, 0.08, 0.1, 0.15, 0.2],
    "min_samples_leaf": [5, 10, 20, 30, 50],
    "l2_regularization": [0.0, 0.01, 0.1, 1.0, 10.0],
}

HGB_QUANTILE_PARAM_DIST = HGB_BASE_PARAM_DIST  # same search space, separate pinball-loss search

QUANTILE_LOWER = ALPHA / 2        # 0.025
QUANTILE_UPPER = 1 - ALPHA / 2    # 0.975

# --------------------------------------------------------- novelty ----
NOVELTY_N_QUARTILES = 4
