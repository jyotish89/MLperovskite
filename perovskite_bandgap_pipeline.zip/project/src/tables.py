"""Phase 6: dataset, model, four-method benchmark, and LOBO tables,
exported as both Markdown and LaTeX."""
from __future__ import annotations
import sys
import json
import pandas as pd

sys.path.insert(0, str(__import__("pathlib").Path(__file__).resolve().parent))
import config as cfg


def df_to_md(df: pd.DataFrame, float_fmt="{:.4f}") -> str:
    d = df.copy()
    for c in d.select_dtypes("float").columns:
        d[c] = d[c].map(lambda x: float_fmt.format(x) if pd.notna(x) else "")
    return d.to_markdown(index=False)


def df_to_latex(df: pd.DataFrame, caption: str, label: str, float_fmt="%.4f") -> str:
    return df.to_latex(index=False, caption=caption, label=label, float_format=float_fmt)


def build_dataset_table(cleaning_report: dict) -> pd.DataFrame:
    rows = [
        {"quantity": "Input rows", "value": cleaning_report["n_input_rows"]},
        {"quantity": "Exact duplicate rows removed", "value": cleaning_report["n_exact_duplicate_rows_removed"]},
        {"quantity": "Fully-missing rows removed", "value": cleaning_report["n_fully_missing_rows_removed"]},
        {"quantity": "Rows retained after cleaning", "value": cleaning_report["n_output_rows"]},
        {"quantity": "Low-fidelity rows", "value": cleaning_report["n_low_fidelity_rows"]},
        {"quantity": "High-fidelity (HSE06-family) rows", "value": cleaning_report["n_high_fidelity_rows"]},
        {"quantity": "Unique low-fidelity formulas", "value": cleaning_report["n_low_fidelity_unique_formulas"]},
        {"quantity": "Unique high-fidelity formulas", "value": cleaning_report["n_high_fidelity_unique_formulas"]},
        {"quantity": "Formulas overlapping between pools", "value": cleaning_report["n_formulas_overlapping_between_pools"]},
        {"quantity": "Rows flagged out of physical range (audit only)", "value": cleaning_report["n_rows_flagged_out_of_physical_range"]},
    ]
    return pd.DataFrame(rows)


def build_model_table(tuned_config: dict) -> pd.DataFrame:
    rows = []
    for name, key in [("Base (MAE)", "base"), ("Quantile 2.5%", "quantile_lower"), ("Quantile 97.5%", "quantile_upper")]:
        d = tuned_config[key]
        rows.append({
            "model": name,
            "quantile": d.get("quantile", ""),
            **d["best_params"],
            "cv_score": d.get("best_cv_score_neg_mae", d.get("best_cv_score_neg_pinball")),
        })
    return pd.DataFrame(rows)


def run():
    with open(cfg.CACHE_DIR / "cleaning_report.json") as f:
        cleaning_report = json.load(f)
    with open(cfg.CACHE_DIR / "tuned_config.json") as f:
        tuned_config = json.load(f)

    agg_df = pd.read_csv(cfg.TAB_DIR / "main_benchmark_aggregate.csv")
    lobo_agg = pd.read_csv(cfg.TAB_DIR / "lobo_aggregate.csv")

    dataset_table = build_dataset_table(cleaning_report)
    model_table = build_model_table(tuned_config)

    tables = {
        "dataset_table": (dataset_table, "Dataset validation and fidelity-pool summary.", "tab:dataset"),
        "model_table": (model_table, "Tuned model configurations (formula-grouped 5-fold CV, 40-iteration randomized search).", "tab:model"),
        "benchmark_table": (agg_df, "Four-method UQ benchmark aggregated over 20 formula-disjoint calibration/test splits (bootstrap CIs).", "tab:benchmark"),
        "lobo_table": (lobo_agg, "Leave-one-site-out extrapolation coverage/width by site type (5 fixed seeds, bootstrap CIs).", "tab:lobo"),
    }

    for name, (df, caption, label) in tables.items():
        with open(cfg.TAB_DIR / f"{name}.md", "w") as f:
            f.write(f"### {caption}\n\n")
            f.write(df_to_md(df))
            f.write("\n")
        with open(cfg.TEX_DIR / f"{name}.tex", "w") as f:
            f.write(df_to_latex(df, caption, label))

    print("Tables written to", cfg.TAB_DIR, "and", cfg.TEX_DIR)
    return tables


if __name__ == "__main__":
    run()
