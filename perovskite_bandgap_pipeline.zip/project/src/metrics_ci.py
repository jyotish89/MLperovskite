"""Confidence-interval utilities: Wilson intervals for individual empirical
coverage proportions, and repetition-level bootstrap/percentile intervals for
aggregate multi-seed metrics."""
from __future__ import annotations
import numpy as np
from scipy import stats


def wilson_interval(successes: int, n: int, confidence: float = 0.95):
    """Wilson score interval for a binomial proportion (individual coverage rows)."""
    if n == 0:
        return (np.nan, np.nan, np.nan)
    p_hat = successes / n
    z = stats.norm.ppf(1 - (1 - confidence) / 2)
    denom = 1 + z**2 / n
    center = (p_hat + z**2 / (2 * n)) / denom
    half = (z * np.sqrt((p_hat * (1 - p_hat) / n) + (z**2 / (4 * n**2)))) / denom
    return p_hat, max(0.0, center - half), min(1.0, center + half)


def bootstrap_ci(values, n_boot=5000, confidence=0.95, seed=0, statistic=np.mean):
    """Percentile bootstrap CI for an aggregate metric over repetitions (e.g. 20 seeds)."""
    values = np.asarray(values, dtype=float)
    values = values[~np.isnan(values)]
    if len(values) == 0:
        return (np.nan, np.nan, np.nan)
    rng = np.random.default_rng(seed)
    boots = np.empty(n_boot)
    n = len(values)
    for i in range(n_boot):
        sample = values[rng.integers(0, n, size=n)]
        boots[i] = statistic(sample)
    lo = np.percentile(boots, 100 * (1 - confidence) / 2)
    hi = np.percentile(boots, 100 * (1 - (1 - confidence) / 2))
    return statistic(values), lo, hi


def empirical_coverage(y_true, lower, upper):
    covered = (y_true >= lower) & (y_true <= upper)
    return covered
