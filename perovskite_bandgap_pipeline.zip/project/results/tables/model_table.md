### Tuned model configurations (formula-grouped 5-fold CV, 40-iteration randomized search).

| model          |   quantile |   min_samples_leaf |   max_leaf_nodes |   max_iter |   max_depth |   learning_rate |   l2_regularization |   cv_score |
|:---------------|-----------:|-------------------:|-----------------:|-----------:|------------:|----------------:|--------------------:|-----------:|
| Base (MAE)     |            |                 10 |               63 |        150 |          12 |            0.08 |                0.01 |    -0.4291 |
| Quantile 2.5%  |      0.025 |                 20 |               31 |        500 |           5 |            0.15 |                0    |    -0.0176 |
| Quantile 97.5% |      0.975 |                 10 |               31 |        500 |           3 |            0.05 |                0.01 |    -0.0586 |
