# Perovskite Band-Gap Uncertainty Pipeline

Reproducible pipeline for `data/master_composition_bandgap.csv`: validated
data products, tuned models, repeated conformal/quantile/GPR uncertainty
benchmarks, extrapolation analyses, figures, tables, and a manuscript draft.

## Quickstart (Colab-friendly, each stage checkpointed)

```bash
pip install -r requirements.txt
python scripts/run_validation.py          # Phase 1: clean + audit -> data/checkpoints/
python scripts/run_tuning.py              # Phase 2: tune base + quantile models
python scripts/run_repeated_benchmark.py  # Phase 3: 20-seed UQ benchmark
python scripts/run_lobo.py                # Phase 4: LOBO + novelty
python scripts/run_sensitivity.py         # Phase 5: Mondrian/GPR sensitivity
python scripts/build_report.py            # Phase 6: figures, tables, manuscript
```

Every stage reads its inputs from `data/checkpoints/` (parquet/CSV/JSON) and
writes its own outputs there, so any stage can be re-run independently once
its prerequisites exist, and the whole pipeline can be resumed after a
Colab disconnect. Random search, seeds, and dependency versions used for
tuning are all logged in `data/checkpoints/tuned_config.json`.

## Fixed scientific decisions (see `src/config.py` for the authoritative copy)

- Group key: `formula`, used for every grouped CV split and every
  calibration/test partition (verified formula-disjoint at run time via an
  assertion in `repeated_evaluation.py`).
- Cleaning removes only literal exact-duplicate rows and rows that are
  "fully missing" (every site + geometric descriptor column absent).
  Same-formula rows that differ are kept, not aggregated. The four derived
  geometric descriptors were verified numerically consistent with r_A/r_B/r_X
  (max reconstruction error ~1e-15), so no additional exclusions were made on
  physical-implausibility grounds; out-of-typical-range values are flagged in
  the audit report but retained (never silently dropped).
- High-fidelity pool = the three specified HSE06-family `calc_method` values;
  everything else is low-fidelity. The pipeline fails loudly (raises) if
  required columns are missing, if any formula is missing, or if the
  high-fidelity filter matches zero rows.
- Base + both quantile HistGradientBoostingRegressors are tuned exactly once,
  via formula-grouped 5-fold CV and 40-iteration randomized search each, on
  the complete low-fidelity pool, then reused unmodified through every later
  stage.
- Main benchmark: 20 independently seeded, formula-disjoint calibration/test
  splits (50/50) of the high-fidelity pool, evaluating all four UQ methods
  (global conformal, Mondrian/B-site conformal, quantile-GB, GPR).
- LOBO: complete A-site, B-site, and X-site leave-one-group-out analyses on
  5 fixed, documented seeds (not nested across all 20 main seeds). See the
  design note at the top of `src/extrapolation.py` for exactly how the five
  seeds are used (independent calibration subsamples of the non-held-out
  pool, sized to match the main benchmark's calibration fraction).
- GPR sensitivity ladder: 500/1,000/2,000/4,000 low-fidelity training rows;
  no full-data GP is attempted.
- Fixed Mondrian default: B-site calibration groups with fewer than 10 rows
  fall back to the global conformal quantile (swept over 5/10/15/20 in the
  sensitivity phase).
- Fixed conformal quantile convention throughout:
  `ceil((n+1)(1-alpha)) / n` empirical quantile, alpha = 0.05.
- Coverage CIs: Wilson score intervals for individual empirical coverage
  values; percentile bootstrap intervals for metrics aggregated over
  repetitions (20 main seeds, or 5 LOBO seeds x held-out groups).

## Headline results from this run (see `results/` for full detail)

- Cleaned dataset: 10,060 rows retained from 24,798 input rows (494 exact
  duplicates + 14,244 fully-missing rows removed) -- 9,235 low-fidelity,
  825 high-fidelity (HSE06-family), 297 formulas overlapping both pools.
- Main benchmark (20 seeds): global conformal coverage ~96.3% (bootstrap CI
  ~[95.6%, 96.9%]) against a 95% target -- close to nominal, not "reliable"
  in an unqualified sense. Mondrian conformal is similar (~95.8%). Direct
  quantile-GB intervals substantially undercover (~50%). GPR intervals
  undercover moderately (~88-89% at the 4,000-row training size used for the
  main benchmark).
- LOBO: A-site ~97.4%, B-site ~96.9%, X-site ~90.5% coverage -- extrapolating
  to an entirely new X-site species degrades conformal validity the most.
- Novelty quartiles built from Euclidean vs. Mahalanobis distance to the
  low-fidelity reference distribution agree on only ~23% of quartile
  assignments (Spearman correlation ~0.07 between the raw distances) -- novelty
  rankings are not robust to the choice of distance metric in this feature
  space.
- GPR ladder: coverage/width both improve moving from 500 to 4,000 training
  rows but remain below nominal at every ladder point tested.

**Validity caveat** (also stated in `results/markdown/manuscript_summary.md`):
split-conformal validity depends on exchangeability between calibration and
test data. This does not extend to unseen A-site, B-site, or X-site
categories, and the intervals carry no built-in warning for that failure
mode -- see the LOBO and novelty results before trusting an interval for an
unfamiliar composition.

## Layout

```text
data/                       raw CSV + checkpoints/ (parquet/CSV/JSON, all intermediate state)
src/                        all pipeline modules (see docstrings for each phase)
scripts/                    thin CLI wrappers, one per phase, safe to re-run
results/figures/            workflow diagram, parity plot, per-site widths,
                             calibration curve, feature importance, LOBO, novelty
results/tables/              dataset/model/benchmark/LOBO/sensitivity tables (Markdown + CSV)
results/markdown/           manuscript_summary.md
results/latex/               manuscript_summary.tex + table .tex files
```
